.. PKGBUILDer documentation master file, created by
   sphinx-quickstart on Sun Sep 18 14:35:50 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

PKGBUILDer 2.1.1.9 documentation
================================

Contents:

.. toctree::
   :maxdepth: 2

   pkgbuilder
   README
   messagecodes
   LICENSE

.. Indices and tables
.. ==================
..
.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`
